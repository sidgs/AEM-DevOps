package com.aem.training.aemtraining;

/**
 * Utility class used by script.
 */
public class SampleUtil {

    public static String getText() {
        return "Hello World.";
    }
}